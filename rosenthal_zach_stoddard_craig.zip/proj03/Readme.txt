Zachary Rosenthal - rosent76
Craig Stoddard - stodda61

Contributions:
Craig and Zach equally contributed to this project
All of the programming was done as a pair
The uml and design was also done together
This was a perfect 50/50 effort

Expected Functionality:
Works 100%
should compile perfectly and run exceptionally (on cse computer/server)

to compile and run simply type the following in your terminal (assuming ssh'd into cse server)

'make'
'./proj03'


this should compile and run the program without issue.

Thank you and Good night :)
